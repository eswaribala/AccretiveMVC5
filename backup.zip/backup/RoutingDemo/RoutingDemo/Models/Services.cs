﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace RoutingDemo.Models
{
    public class Service
    {
         [Key]
         [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public String Name { get; set; }
        public int Charges { get; set; }
        public int CoverageId { get; set; }
        [ForeignKey("CoverageId ")]
        public Coverage coverage { get; set; }
    }
}
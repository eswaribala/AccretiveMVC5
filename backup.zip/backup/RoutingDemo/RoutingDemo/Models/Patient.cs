﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace RoutingDemo.Models
{
    public class Patient
    {
        
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Required(ErrorMessage = "{0} is required.")]
        public int Id { get; set; }
        [StringLength(50,MinimumLength=3)]
        public String Name { get; set; }
        public DateTime DOB { get; set; }
        public String Gender { get; set; }
        public String Address { get; set; }
        public String Email { get; set; }
       
    }
}
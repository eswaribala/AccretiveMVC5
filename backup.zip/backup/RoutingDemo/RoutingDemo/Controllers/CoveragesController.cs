﻿using RoutingDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace RoutingDemo.Controllers
{
    public class CoveragesController : Controller
    {

        private AcccretiveContext ctx;
        // GET: Coverages
        public ActionResult Index()
        {
            ctx = new AcccretiveContext();

            var data = from Patient p in ctx.Patients.ToList()
                       join Coverage c  in ctx.Coverages.ToList() on p.Id equals c.PatientId
                       join Service s in ctx.Services.ToList() on c.SubscriptionId equals s.CoverageId


                       select new {PatientName= p.Name, PayorName=c.PayorName, Coverage=s.coverage,Charges=s.Charges };


            //var json = new JavaScriptSerializer().Serialize(data);
            return Json(data, JsonRequestBehavior.AllowGet);


            
        }
    }
}
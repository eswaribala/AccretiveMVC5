namespace RoutingDemo.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Coverages",
                c => new
                    {
                        SubscriptionId = c.Int(nullable: false),
                        PayorName = c.String(),
                        PatientId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.SubscriptionId)
                .ForeignKey("dbo.Patients", t => t.PatientId, cascadeDelete: true)
                .Index(t => t.PatientId);
            
            CreateTable(
                "dbo.Patients",
                c => new
                    {
                        Id = c.Int(nullable: false),
                        Name = c.String(maxLength: 50),
                        DOB = c.DateTime(nullable: false),
                        Gender = c.String(),
                        Address = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Services",
                c => new
                    {
                        Id = c.Int(nullable: false),
                        Name = c.String(),
                        Charges = c.Int(nullable: false),
                        CoverageId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Coverages", t => t.CoverageId, cascadeDelete: true)
                .Index(t => t.CoverageId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Services", "CoverageId", "dbo.Coverages");
            DropForeignKey("dbo.Coverages", "PatientId", "dbo.Patients");
            DropIndex("dbo.Services", new[] { "CoverageId" });
            DropIndex("dbo.Coverages", new[] { "PatientId" });
            DropTable("dbo.Services");
            DropTable("dbo.Patients");
            DropTable("dbo.Coverages");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AuthenticationDemo.Repository
{
    public static class UserRepository
    {

        static List<User> users = new List<User>() {

        new User() {Email="abc@gmail.com",Roles="Admin,Editor",Password="abcadmin" },
        new User() {Email="xyz@gmail.com",Roles="Editor",Password="xyzeditor" },
        new User() {Email="param@gmail.com",Roles="Developer",Password="viki123" }
    };

        public static User GetUserDetails(User user)
        {
            return users.Where(u => u.Email.ToLower() == user.Email.ToLower() &&
            u.Password == user.Password).FirstOrDefault();
        }
    }
}
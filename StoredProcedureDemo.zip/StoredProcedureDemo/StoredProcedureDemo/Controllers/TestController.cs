﻿using StoredProcedureDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace StoredProcedureDemo.Controllers
{
    public class TestController : Controller
    {
        private FidelityDBEntities ctx;
        // GET: Test
        public ActionResult Index()
        {

            ctx = new FidelityDBEntities();

            StudentInfo newStudent = new StudentInfo() { Name = "Shailja",DoB=new DateTime(1993,3,3),standard_Id=1 };

            ctx.StudentInfoes.Add(newStudent);
            //will execute sp_InsertStudentInfo 
            ctx.SaveChanges();

            StandardInfo stdinfo = new StandardInfo() { Name="Fifth"};
            ctx.StandardInfoes.Add(stdinfo);
            ctx.SaveChanges();

            //alternative approach
            //var std = ctx.Database.SqlQuery<StandardInfo>("dbo.sp_InsertStandardInfo @Name", "Sixth").SingleOrDefault();

            

            var query = ctx.GetStudentById(1);

            return Json(query,JsonRequestBehavior.AllowGet);
        }
    }
}

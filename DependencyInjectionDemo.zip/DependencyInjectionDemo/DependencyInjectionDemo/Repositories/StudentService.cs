﻿using DependencyInjectionDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DependencyInjectionDemo.Repositories
{
    public class StudentService:IStudentService
    {
        private IList<Student> StudentList;

        public StudentService()
        {
            StudentList = new List<Student>();
            StudentList.Add(new Student {StudentId=1,Name="Sushanth",DOB=new DateTime(1994,1,1) });
            StudentList.Add(new Student { StudentId = 1, Name = "Sushanth", DOB = new DateTime(1994, 1, 1) });
            StudentList.Add(new Student { StudentId = 2, Name = "Jhonny", DOB = new DateTime(1980, 1, 1) });
            StudentList.Add(new Student { StudentId = 3, Name = "Seema", DOB = new DateTime(1970, 1, 1) });
        }
        public void AddStudent(Models.Student student)
        {
            StudentList.Add(student);
        }

        public IList<Models.Student> GetAll()
        {
            return StudentList;
        }
    }
}
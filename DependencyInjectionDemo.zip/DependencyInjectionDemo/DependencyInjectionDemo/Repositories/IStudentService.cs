﻿using DependencyInjectionDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInjectionDemo.Repositories
{
    public interface IStudentService
    {
        void AddStudent(Student student);
        IList<Student> GetAll();

    }
}

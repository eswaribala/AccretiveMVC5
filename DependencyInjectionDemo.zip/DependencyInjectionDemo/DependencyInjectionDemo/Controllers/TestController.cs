﻿using DependencyInjectionDemo.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DependencyInjectionDemo.Controllers
{
    public class TestController : Controller
    {
        IStudentService repository;

        public TestController(IStudentService repo)
        {

            repository = repo;


        }
        // GET: Test
        public ActionResult Index()
        {

            return Json(repository.GetAll(),JsonRequestBehavior.AllowGet);
        }
    }
}
﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(RoutingDemo.Startup))]
namespace RoutingDemo
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}

﻿using RoutingDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RoutingDemo.Controllers
{
    [RoutePrefix("home")]
    public class CoverageController : Controller
    {
        // GET: Coverage
        public ActionResult Index()
        {
            return View();
        }

        public List<Coverage> GetData()
        {
            List<Coverage> coverageList = new List<Coverage>();
            coverageList.Add(new Coverage { SubscriptionId=345687, PayorName="Saxena"});
            coverageList.Add(new Coverage { SubscriptionId = 345687, PayorName = "Saxena" });
            coverageList.Add(new Coverage { SubscriptionId = 344568, PayorName = "Suman" });
            coverageList.Add(new Coverage { SubscriptionId = 3454648, PayorName = "David" });
            coverageList.Add(new Coverage { SubscriptionId = 43587, PayorName = "Banu" });
            return coverageList;
        }
        [Route("")]
        [Route("home")]
        [Route("home/index")]
        public JsonResult CoverageData()
        {
            return Json(GetData(), JsonRequestBehavior.AllowGet);

        }

        [Route("ViewCoverage")]
        public ActionResult ViewCoverageData()
        {
            ViewBag.Coverages = GetData();
            return View();
        }
        [Route("subsc/{id}")]
        //constraint 
        [Route("subsc/{id:int}")]
        public ActionResult Details(int id)
        {
            Coverage rcoverage=null;
            foreach(Coverage coverage in GetData())
            {
                if (coverage.SubscriptionId == id)
                    rcoverage = coverage;
            }
            return View(rcoverage);
        }

    }
}
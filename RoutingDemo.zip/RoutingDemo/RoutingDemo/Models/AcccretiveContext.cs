﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace RoutingDemo.Models
{
    public class AcccretiveContext:DbContext
    {
       public AcccretiveContext():base("AccretiveConn")
        {

        }
       public DbSet<Patient> Patients { get; set; }
       public DbSet<Coverage> Coverages { get; set; }
       public DbSet<Service> Services { get; set; }
    }
}
﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(FluentAPIDemo.Startup))]
namespace FluentAPIDemo
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}

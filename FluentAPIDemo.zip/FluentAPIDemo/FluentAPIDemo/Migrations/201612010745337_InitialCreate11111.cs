namespace FluentAPIDemo.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate11111 : DbMigration
    {
        public override void Up()
        {
            AddColumn("Admin.StudentInfo", "Phone_No", c => c.Long());
        }
        
        public override void Down()
        {
            DropColumn("Admin.StudentInfo", "Phone_No");
        }
    }
}

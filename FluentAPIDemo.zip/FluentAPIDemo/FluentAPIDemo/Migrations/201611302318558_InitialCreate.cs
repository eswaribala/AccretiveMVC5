namespace FluentAPIDemo.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.StandardInfo",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "Admin.StudentInfo",
                c => new
                    {
                        RegNo = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        standard_Id = c.Int(),
                    })
                .PrimaryKey(t => t.RegNo)
                .ForeignKey("dbo.StandardInfo", t => t.standard_Id)
                .Index(t => t.standard_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("Admin.StudentInfo", "standard_Id", "dbo.StandardInfo");
            DropIndex("Admin.StudentInfo", new[] { "standard_Id" });
            DropTable("Admin.StudentInfo");
            DropTable("dbo.StandardInfo");
        }
    }
}

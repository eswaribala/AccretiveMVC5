namespace FluentAPIDemo.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate1111 : DbMigration
    {
        public override void Up()
        {
            DropPrimaryKey("Admin.StudentInfo");
            AlterColumn("Admin.StudentInfo", "Name", c => c.String(nullable: false, maxLength: 50, fixedLength: true));
            AddPrimaryKey("Admin.StudentInfo", new[] { "RegNo", "Name" });
        }
        
        public override void Down()
        {
            DropPrimaryKey("Admin.StudentInfo");
            AlterColumn("Admin.StudentInfo", "Name", c => c.String(nullable: false, maxLength: 128));
            AddPrimaryKey("Admin.StudentInfo", new[] { "RegNo", "Name" });
        }
    }
}

namespace FluentAPIDemo.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate1 : DbMigration
    {
        public override void Up()
        {
            DropPrimaryKey("Admin.StudentInfo");
            AlterColumn("Admin.StudentInfo", "RegNo", c => c.Int(nullable: false));
            AlterColumn("Admin.StudentInfo", "Name", c => c.String(nullable: false, maxLength: 128));
            AddPrimaryKey("Admin.StudentInfo", new[] { "RegNo", "Name" });
        }
        
        public override void Down()
        {
            DropPrimaryKey("Admin.StudentInfo");
            AlterColumn("Admin.StudentInfo", "Name", c => c.String());
            AlterColumn("Admin.StudentInfo", "RegNo", c => c.Int(nullable: false, identity: true));
            AddPrimaryKey("Admin.StudentInfo", "RegNo");
        }
    }
}

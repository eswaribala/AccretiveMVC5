﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace FluentAPIDemo.Models
{
    public class StudentDBContext:DbContext
    {
        public StudentDBContext():base("FidelityDBConn")
        {

        }

        public DbSet<Student> Students { get; set; }
        public DbSet<Standard> Standards { get; set; }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //Configure default schema
            modelBuilder.HasDefaultSchema("Admin");

            //Map entity to table
            modelBuilder.Entity<Student>().ToTable("StudentInfo");
            modelBuilder.Entity<Student>().HasKey<int>(s => s.RegNo);
            //Configure composite primary key
            modelBuilder.Entity<Student>().HasKey<Object>(s => new { s.RegNo, s.Name });
            //Configure Column
            modelBuilder.Entity<Student>()
                        .Property(p => p.DateOfBirth)
                        .HasColumnName("DoB")
                        .HasColumnOrder(3)
                        .HasColumnType("datetime2");

            modelBuilder.Entity<Student>()
                        .Property(p => p.PhoneNo)
                        .HasColumnName("Phone_No")
                        .HasColumnOrder(4)
                        .HasColumnType("bigint");
            modelBuilder.Entity<Student>()
                    .Property(p => p.DateOfBirth)
                    .IsOptional();
            modelBuilder.Entity<Student>()
                  .Property(p => p.PhoneNo)
                  .IsOptional();

            //Configure NotNull Column
            modelBuilder.Entity<Student>()
                .Property(p => p.Name)
                .IsRequired();

            //Set StudentName column size to 50
            modelBuilder.Entity<Student>()
                    .Property(p => p.Name)
                    .HasMaxLength(50);

            //Set StudentName column size to 50 and change datatype to nchar 
            //IsFixedLength() change datatype from nvarchar to nchar
            modelBuilder.Entity<Student>()
                    .Property(p => p.Name)
                    .HasMaxLength(50).IsFixedLength();

            //Set size decimal(2,2)
            //modelBuilder.Entity<Student>()
            //    .Property(p => p.Height)
            //    .HasPrecision(2, 2);

            //configure one-to-many
        //modelBuilder.Entity<Standard>()
        //            .HasMany<Student>(s => s.Students) Standard has many Students
        //            .WithRequired(s => s.Standard)  Student require one Standard
        //            .HasForeignKey(s => s.StdId);Student includes specified foreignkey property name for Standard

            modelBuilder.Entity<Standard>().ToTable("StandardInfo", "dbo");

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AreaDemo.Repository
{
    public class SMSLogger:ILogger
    {
        public String  SaveMessage()
        {
            return  ("Logged in SMS");
        }
    }
}
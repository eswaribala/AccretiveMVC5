﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AreaDemo.Areas.Admin.Models
{
    public class EmployeeData
    {
        private IList<Employee> employeeList;
        public EmployeeData()
        {
            employeeList = new List<Employee>();
            employeeList.Add(new Employee { EmployeeId = 1233, Name = "Amudha", DOB = new DateTime(1995, 1, 1) });
            employeeList.Add(new Employee { EmployeeId = 1233, Name = "Anoop", DOB = new DateTime(1998,2, 12) });
            employeeList.Add(new Employee { EmployeeId = 1233, Name = "Santhosh", DOB = new DateTime(1970, 7, 11) });
            employeeList.Add(new Employee { EmployeeId = 1233, Name = "Karthik", DOB = new DateTime(1965, 5, 21) });

        }

        public IList<Employee> GetAll()
        {
            return employeeList;
        }


    }
}
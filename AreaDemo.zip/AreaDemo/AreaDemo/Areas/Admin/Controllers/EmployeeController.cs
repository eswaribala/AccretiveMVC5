﻿using AreaDemo.Areas.Admin.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AreaDemo.Areas.Admin.Controllers
{
    public class EmployeeController : Controller
    {
        private EmployeeData employeeData;
        // GET: Admin/Employee
        public String Index()
        {
            employeeData = new EmployeeData();
            JsonSerializerSettings microsoftDateFormatSettings = new JsonSerializerSettings
            {
        DateFormatHandling = DateFormatHandling.MicrosoftDateFormat
            };
    string microsoftJson = JsonConvert.SerializeObject(employeeData.GetAll(), microsoftDateFormatSettings);
   // {"Details":"Application started.","LogDate":"\/Date(1234656000000)\/"}

    string javascriptJson = JsonConvert.SerializeObject(employeeData.GetAll(), new JavaScriptDateTimeConverter());
    // {"Details":"Application started.","LogDate":new Date(1234656000000)}

            return javascriptJson;
        }
    }
}
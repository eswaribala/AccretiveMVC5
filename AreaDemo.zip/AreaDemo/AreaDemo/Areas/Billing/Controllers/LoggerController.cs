﻿using AreaDemo.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AreaDemo.Areas.Billing.Controllers
{
    public class LoggerController : Controller
    {
        private ILogger repository;
        public LoggerController(ILogger repo)
        {
            repository = repo;
        }
        // GET: Billing/Logger
        public String Index()
        {

            return repository.SaveMessage();
        }
    }
}
﻿var accmodule = angular.module("AccModule", []);

accmodule.controller('AccCoverage', ['$scope', '$http', function ($scope,$http) {
    //model
    //
    $http({
        method: 'get',
        datatype: 'jsonp',
      
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'

        },
        url: 'http://localhost:36685/Coverages'

    }).success(function (data) {
        $scope.result = data;
        console.log($scope.result);

    });



}]);